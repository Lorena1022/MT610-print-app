package com.miguel.mt610print;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Setup screen: pick the printer, find the right mode with test prints, print files. */
public class MainActivity extends Activity {
    private static final int REQ_BT = 1;
    private static final int REQ_FILE = 2;

    private Settings settings;
    private final List<String[]> devices = new ArrayList<>();   // {name, mac}
    private Spinner deviceSpinner;
    private TextView status;
    private TextView log;
    private EditText widthField;
    private TextView thresholdLabel;
    private volatile boolean busy;
    private Uri pendingShare;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        settings = Settings.load(this);
        setContentView(buildUi());
        ensurePermission();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDevices();
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("MT610 Print");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setPadding(0, dp(4), 0, dp(12));
        root.addView(status);

        // --- printer
        root.addView(header("1. Printer"));
        root.addView(hint("Pair the printer in Android Bluetooth settings first if it isn't listed."));
        deviceSpinner = new Spinner(this);
        root.addView(deviceSpinner);
        deviceSpinner.setOnItemSelectedListener(new SimpleSelect(pos -> {
            if (pos < devices.size()) {
                settings.name = devices.get(pos)[0];
                settings.mac = devices.get(pos)[1];
                settings.save(this);
                updateStatus();
            }
        }));
        Button btSettings = button("Open Bluetooth settings", v ->
                startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)));
        root.addView(btSettings);

        // --- mode
        root.addView(header("2. Find the mode that works"));
        root.addView(hint("Pick a mode and tap Print test. If the strip reads \"MODE n WORKS\", you're done. "
                + "If it prints junk or nothing, turn the printer off and on, pick the next mode and try again."));
        Spinner modeSpinner = spinner(Protocols.NAMES, settings.protocol, pos -> {
            settings.protocol = pos;
            settings.save(this);
        });
        root.addView(modeSpinner);
        root.addView(button("Print test", v -> printTest()));

        // --- page
        root.addView(header("3. Paper & quality"));
        root.addView(label("Printer resolution"));
        root.addView(spinner(new String[]{"203 dpi (MT610)", "300 dpi (MT610 Pro)"},
                settings.dpi == Settings.DPI_300 ? 1 : 0, pos -> {
                    int dpi = pos == 1 ? Settings.DPI_300 : Settings.DPI_203;
                    if (dpi != settings.dpi) {
                        settings.dpi = dpi;
                        settings.widthDots = Settings.defaultWidth(dpi);
                        widthField.setText(String.valueOf(settings.widthDots));
                        settings.save(this);
                    }
                }));
        root.addView(label("Print width in dots (8.5\" Letter = 1728 at 203 dpi)"));
        widthField = new EditText(this);
        widthField.setInputType(InputType.TYPE_CLASS_NUMBER);
        widthField.setText(String.valueOf(settings.widthDots));
        root.addView(widthField);

        root.addView(label("After each page"));
        root.addView(spinner(Protocols.PAGE_END, settings.pageEnd, pos -> {
            settings.pageEnd = pos;
            settings.save(this);
        }));

        CheckBox dither = new CheckBox(this);
        dither.setText("Photo mode (dither pictures instead of sharp text)");
        dither.setChecked(settings.dither);
        dither.setOnCheckedChangeListener((b, on) -> {
            settings.dither = on;
            settings.save(this);
        });
        root.addView(dither);

        thresholdLabel = label("");
        root.addView(thresholdLabel);
        SeekBar darkness = new SeekBar(this);
        darkness.setMax(200);
        darkness.setProgress(settings.threshold - 30);
        updateThresholdLabel();
        darkness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                settings.threshold = p + 30;
                updateThresholdLabel();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {}

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                settings.save(MainActivity.this);
            }
        });
        root.addView(darkness);

        root.addView(label("ESC/POS rows per block (lower if pages print cut off)"));
        root.addView(spinner(new String[]{"32", "64", "128", "255"},
                indexOf(new int[]{32, 64, 128, 255}, settings.bandLines, 2), pos -> {
                    settings.bandLines = new int[]{32, 64, 128, 255}[pos];
                    settings.save(this);
                }));

        // --- use it
        root.addView(header("4. Print from any app"));
        root.addView(hint("Turn on \"MT610 Print\" once in Android's print settings. After that, use "
                + "Print in Chrome, Gmail, PDF viewers, etc. and pick the MT610. "
                + "You can also Share a PDF or picture to this app."));
        root.addView(button("Open Android print settings", v ->
                startActivity(new Intent(android.provider.Settings.ACTION_PRINT_SETTINGS))));
        root.addView(button("Print a PDF or picture...", v -> pickFile()));

        log = new TextView(this);
        log.setTypeface(Typeface.MONOSPACE);
        log.setTextSize(12);
        log.setPadding(0, dp(16), 0, 0);
        root.addView(log);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        updateStatus();
        return scroll;
    }

    private void updateThresholdLabel() {
        thresholdLabel.setText("Text darkness: " + settings.threshold
                + " (higher = bolder text, lower = lighter)");
    }

    private void updateStatus() {
        if (status == null) return;
        String printer = settings.mac == null ? "none picked" : settings.name + " (" + settings.mac + ")";
        status.setText("Printer: " + printer);
    }

    // --------------------------------------------------------- Bluetooth

    private boolean hasPermission() {
        return Build.VERSION.SDK_INT < 31
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensurePermission() {
        if (!hasPermission() && Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_BT) {
            if (hasPermission()) {
                refreshDevices();
                if (pendingShare != null) {
                    Uri u = pendingShare;
                    pendingShare = null;
                    printUri(u);
                }
            } else {
                appendLog("Bluetooth (Nearby devices) permission is needed to talk to the printer.");
            }
        }
    }

    private void refreshDevices() {
        if (deviceSpinner == null) return;
        devices.clear();
        if (hasPermission()) {
            BluetoothManager bm = getSystemService(BluetoothManager.class);
            BluetoothAdapter a = bm == null ? null : bm.getAdapter();
            if (a != null) {
                try {
                    for (BluetoothDevice d : a.getBondedDevices()) {
                        String n = d.getName() == null ? d.getAddress() : d.getName();
                        String[] entry = {n, d.getAddress()};
                        // Put HPRT/MT610 printers at the top.
                        if (n.toUpperCase().startsWith("MT6") || n.toUpperCase().contains("HPRT")) {
                            devices.add(0, entry);
                        } else {
                            devices.add(entry);
                        }
                    }
                } catch (SecurityException e) {
                    appendLog("No Bluetooth permission.");
                }
            }
        }
        List<String> labels = new ArrayList<>();
        int selected = 0;
        for (int i = 0; i < devices.size(); i++) {
            labels.add(devices.get(i)[0] + "  (" + devices.get(i)[1] + ")");
            if (devices.get(i)[1].equals(settings.mac)) selected = i;
        }
        if (labels.isEmpty()) labels.add("No paired Bluetooth devices");
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels);
        deviceSpinner.setAdapter(ad);
        deviceSpinner.setSelection(selected);
        if (settings.mac == null && !devices.isEmpty()) {
            settings.name = devices.get(0)[0];
            settings.mac = devices.get(0)[1];
            settings.save(this);
        }
        updateStatus();
    }

    // ------------------------------------------------------------ printing

    private void applyWidth() {
        try {
            int w = Integer.parseInt(widthField.getText().toString().trim());
            settings.widthDots = w;
        } catch (NumberFormatException ignored) {
        }
        settings.save(this);
        settings = Settings.load(this);
        widthField.setText(String.valueOf(settings.widthDots));
    }

    private void printTest() {
        applyWidth();
        run("Test, mode " + (settings.protocol + 1),
                new Raster.SingleBitmap(Raster.testStrip(settings.protocol)));
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*"});
        startActivityForResult(i, REQ_FILE);
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_FILE && result == RESULT_OK && data != null && data.getData() != null) {
            printUri(data.getData());
        }
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        Uri uri = null;
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        } else if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            uri = intent.getData();
        }
        if (uri == null) return;
        setIntent(new Intent(this, MainActivity.class));   // don't reprint on rotate
        if (!hasPermission()) {
            pendingShare = uri;
            return;
        }
        printUri(uri);
    }

    private void printUri(Uri uri) {
        applyWidth();
        String type = getContentResolver().getType(uri);
        boolean pdf = type != null ? type.equals("application/pdf")
                : uri.toString().toLowerCase().endsWith(".pdf");
        File tmp = new File(getCacheDir(), pdf ? "share.pdf" : "share.img");
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new IOException("Can't open file");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (IOException e) {
            appendLog("Couldn't read file: " + e.getMessage());
            return;
        }
        try {
            Raster.PageSource src = pdf ? new Raster.PdfSource(tmp, null) : new Raster.ImageSource(tmp);
            run(pdf ? "PDF" : "Picture", src);
        } catch (IOException e) {
            appendLog("Couldn't open file: " + e.getMessage());
        }
    }

    private void run(String what, Raster.PageSource src) {
        if (busy) {
            Toast.makeText(this, "Still printing, please wait", Toast.LENGTH_SHORT).show();
            try {
                src.close();
            } catch (IOException ignored) {
            }
            return;
        }
        if (!hasPermission()) {
            ensurePermission();
            return;
        }
        busy = true;
        final Settings s = Settings.load(this);
        appendLog("-- " + what + " --");
        new Thread(() -> {
            try {
                PrintEngine.print(this, s, src, 1, this::appendLog, new AtomicBoolean(false));
            } catch (IOException | RuntimeException e) {
                appendLog("Failed: " + e.getMessage());
            } finally {
                try {
                    src.close();
                } catch (IOException ignored) {
                }
                busy = false;
            }
        }, "print").start();
    }

    private void appendLog(String msg) {
        runOnUiThread(() -> {
            log.append(msg + "\n");
            status.setText(msg);
        });
    }

    // ------------------------------------------------------------ helpers

    private TextView header(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(18), 0, dp(4));
        return t;
    }

    private TextView hint(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setAlpha(0.75f);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return b;
    }

    private Spinner spinner(String[] items, int selected, IntCallback onPick) {
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        s.setSelection(selected);
        s.setOnItemSelectedListener(new SimpleSelect(onPick));
        return s;
    }

    private static int indexOf(int[] arr, int v, int fallback) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == v) return i;
        return fallback;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    interface IntCallback {
        void call(int value);
    }

    private static final class SimpleSelect implements AdapterView.OnItemSelectedListener {
        private final IntCallback cb;

        SimpleSelect(IntCallback cb) {
            this.cb = cb;
        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            cb.call(position);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {}
    }
}
